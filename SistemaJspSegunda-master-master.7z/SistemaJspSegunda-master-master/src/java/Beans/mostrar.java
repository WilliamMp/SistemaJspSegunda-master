/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author willi
 */
public class mostrar {
                   public void show() {
        String sql = "SELECT * FROM `imagem` WHERE 1";
    }
}
